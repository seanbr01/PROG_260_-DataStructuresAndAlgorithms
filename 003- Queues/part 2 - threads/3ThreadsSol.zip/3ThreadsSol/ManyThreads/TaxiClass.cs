﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManyThreads
{
    class Taxi
    {
        public int[] theArray { get; set; }
        public int subTotal_1 { get; set; }
        public int subTotal_2 { get; set; }
        public int subTotal_3 { get; set; }

    }
}
