﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoLL
{
    class WorkItem
    {
        public int Value { get; set; }
        public string Why { get; set; }
        public string What { get; set; }
    }
}
