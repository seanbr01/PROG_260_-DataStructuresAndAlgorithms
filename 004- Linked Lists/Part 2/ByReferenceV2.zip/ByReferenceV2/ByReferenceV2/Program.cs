﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ByReferenceV2
{
    class Thing
    {
        public string someText { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {

            Thing first = new Thing();
            first.someText = "hello";

            Thing second = first;

            Console.WriteLine(first.someText);
            Console.WriteLine(second.someText);

            first = null;

            Console.WriteLine(first.someText);  // comment this out after blows up, what will happen?
            Console.WriteLine(second.someText);

            Console.ReadLine();
        }
    }
}
